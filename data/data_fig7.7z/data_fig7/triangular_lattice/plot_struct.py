#!/usr/bin/env python3
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
import pprint

import csv
N = 251

ticks = [0, 125, 250, 375, 500]
labels = ['-1', '-0.5', '0', '0.5', '1']
infile = open('ssz.csv', 'r')
z1 = [row for row in csv.reader(infile)]
infile.close()

for r in range(0,len(z1)):
    for c in range(0, len(z1[0])):
        z1[r][c] =  float(z1[r][c])

x, y = np.meshgrid(np.arange(0, N, 1),np.arange(0, N, 1))

fig = plt.figure()

ax = plt.axes()
plt.imshow(z1, interpolation='bicubic', cmap=mpl.cm.rainbow, origin = 'lower')
ax.axes.set_xticks(ticks, minor=False)
ax.axes.set_yticks(ticks, minor=False)
ax.axes.set_yticklabels(labels, fontdict=None, minor=False)
ax.axes.set_xticklabels(labels, fontdict=None, minor=False)
ax.set_xlim(125, 375)
ax.set_ylim(125, 375)
plt.colorbar()
plt.savefig('struct.png', dpi=300)

