#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <math.h>

typedef struct point_t {
    double sx;
    double sy;
    double sz;
    double x;
    double y;
    double z;
} spin;

using namespace std;
int main()
{
ifstream inp;
ifstream inp2; 
ofstream out;
FILE *ssz;
ssz = fopen("ssz.csv", "w");
spin *inp_conf;
double a, b, c, d, Qend=3.14, Qst=-3.14, Qh, CXi, CYi, CXr, CYr;
char buf1[100], buf2[100];
int n = 128, pref = 0, num_conf = 1;
int step_number = 4, N = 500;
double *SQ= NULL, *Q= NULL;
size_t size = n * n * step_number * sizeof(spin);
size_t qsize = (N+1)*(N+1) * sizeof(double);
inp_conf = (spin *) malloc(size);
Q = (double*) malloc((N+1)*sizeof(double));
SQ = (double*) malloc(qsize);
    
    Qh = (Qend-Qst)/N;

    for (int z = 0; z < N+1; z++) {
        Q[z]=Qend-Qh*z;
    }

inp2.open("coord.skyrmion.out");
inp.open("conf0");



	for (int i = 0; i < n * n; i++) {
    		inp >> inp_conf[i].sx  >> inp_conf[i].sy  >> inp_conf[i].sz;
    	}
	for (int i = 0; i < n * n; i++) {
    		inp2 >> a >> inp_conf[i].x  >> inp_conf[i].y  >> inp_conf[i].z >> b >> c;
    	}
	inp.close();
	inp2.close();

    for (int ii = 0; ii < N+1; ii++){
        for (int jj = 0; jj < N+1; jj++){
            CXr=0;
            CYr=0;
            CXi=0;
            CYi=0;
            for (int m = 0; m < n; m++){
                for (int p = 0; p < n; p++){
                    CXr += inp_conf[m * n + p].sx * cos((inp_conf[m * n + p].x*Q[ii]+inp_conf[m * n + p].y*Q[jj]));
                    CYr += inp_conf[m * n + p].sy * cos((inp_conf[m * n + p].x*Q[ii]+inp_conf[m * n + p].y*Q[jj]));
                    CXi += inp_conf[m * n + p].sx * sin((inp_conf[m * n + p].x*Q[ii]+inp_conf[m * n + p].y*Q[jj]));
                    CYi += inp_conf[m * n + p].sy * sin((inp_conf[m * n + p].x*Q[ii]+inp_conf[m * n + p].y*Q[jj]));
                }
            }
            CXr=fabs(CXr*CXr-CXi*CXi);
            CYr=fabs(CYr*CYr-CYi*CYi);
            SQ[ii * (N+1) + jj] = sqrt(CXr*CXr + CYr*CYr);
        }
    }

    for (int i = 0; i < N+1; i++) {
        for (int j = 0; j < N+1; j++) {
            if (j==N){
                fprintf(ssz,"%6.8lf ", SQ[i*(N+1)+j]/n/n);
            }
            else{fprintf(ssz,"%6.8lf, ", SQ[i*(N+1)+j]/n/n);}
        }
        fprintf(ssz,"\n");
    }

}
