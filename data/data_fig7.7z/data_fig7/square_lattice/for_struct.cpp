#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <math.h>

typedef struct point_t {
    double sx;
    double sy;
    double sz;
    double x;
    double y;
    double z;
} spin;

using namespace std;
int main()
{
ifstream inp;
ifstream inp2; 
ofstream out;
spin *inp_conf;
double  b, c, d, Qend=3.14, Qst=-3.14, Qh, CXi, CYi, CXr, CYr;
char buf1[100], buf2[100], inp_fi[100];
int n = 64, pref = 0, num_conf = 1;
int label[4];
char a[10];
int step_number = 3, N = 500;
double *SQ= NULL, *Q= NULL;

size_t size = n * n * step_number * sizeof(spin);
size_t qsize = (N+1)*(N+1) * sizeof(double);
inp_conf = (spin *) malloc(size);
Q = (double*) malloc((N+1)*sizeof(double));
SQ = (double*) malloc(qsize);
    
    Qh = (Qend-Qst)/N;

    for (int z = 0; z < N+1; z++) {
        Q[z]=Qend-Qh*z;
    }


for (int z = 0; z < 4; z++){
    sprintf(buf1, "conf%d", z);
    inp2.open(buf1);
	for (int i = 0; i < n * n; i++) {
    		inp2 >> inp_conf[i].sx  >> inp_conf[i].sy  >> inp_conf[i].sz;
    	}
	inp2.close();

    for (int ii = 0; ii < N+1; ii++){
        for (int jj = 0; jj < N+1; jj++){
            CXr=0;
            CYr=0;
            CXi=0;
            CYi=0;
            for (int m = 0; m < n; m++){
                for (int p = 0; p < n; p++){
                    CXr += inp_conf[m * n + p].sx * cos((m * Q[ii]+ p * Q[jj]));
                    CYr += inp_conf[m * n + p].sy * cos((m * Q[ii]+ p * Q[jj]));
                    CXi += inp_conf[m * n + p].sx * sin((m * Q[ii]+ p * Q[jj]));
                    CYi += inp_conf[m * n + p].sy * sin((m * Q[ii]+ p * Q[jj]));
                }
            }
            CXr=fabs(CXr*CXr-CXi*CXi);
            CYr=fabs(CYr*CYr-CYi*CYi);
            SQ[ii * (N+1) + jj] = sqrt(CXr*CXr + CYr*CYr);
        }
    }

    sprintf(buf2, "struct_%d", z);
    out.open(buf2);
    for (int i = 0; i < (N+1) * (N+1); i++) {
        out << SQ[i]/n/n << endl;
    }
    out.close();
}
    
}
