#!/usr/bin/env python3
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
import pprint


kk = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

ticks = [0, 125, 250, 375, 500]
labels = ['-1', '-0.5', '0', '0.5', '1']

for k in kk:
    z=[]
    f = open('struct_{0}'.format(k), 'r')
    x = None
    x=[[],[]]
    
    for line in f:
        line = [float(num) for num in line.split()]
        x[0].append(float(line[0]))

    z=np.asarray(x[0])

    z = np.reshape(z, (501, 501))

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.axes.set_xticks(ticks, minor=False)
    ax.axes.set_yticks(ticks, minor=False)
    ax.axes.set_yticklabels(labels, fontdict=None, minor=False)
    ax.axes.set_xticklabels(labels, fontdict=None, minor=False)
    plt.imshow(z, interpolation='bicubic', cmap=mpl.cm.rainbow, origin = 'lower')
    ax.set_xlim(125, 375)
    ax.set_ylim(125, 375)
    plt.colorbar()
    plt.savefig('struct_{0}.png'.format(k), dpi=300)



